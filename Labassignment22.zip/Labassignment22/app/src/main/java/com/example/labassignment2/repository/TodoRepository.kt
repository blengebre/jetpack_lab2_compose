package com.example.labassignment2.repository

import com.example.labassignment2.data.TodoDao
import com.example.labassignment2.model.Todo
import com.example.labassignment2.network.TodoApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class TodoRepository(
    private val todoDao: TodoDao,
    private val apiService: TodoApiService
) {
    fun getTodos(): Flow<List<Todo>> = flow {
        try {
            // First try to get from local database
            val localTodos = todoDao.getAllTodos()
            if (localTodos.isNotEmpty()) {
                emit(localTodos)
            }

            // Then fetch from network
            val remoteTodos = apiService.getTodos()
            // Update local database
            todoDao.insertAll(remoteTodos)
            emit(remoteTodos)
        } catch (e: Exception) {
            // If network fails, emit local data if available
            val localTodos = todoDao.getAllTodos()
            if (localTodos.isNotEmpty()) {
                emit(localTodos)
            } else {
                throw e
            }
        }
    }

    suspend fun getTodo(id: Int): Todo {
        try {
            // First try to get from local database
            val localTodo = todoDao.getTodoById(id)
            if (localTodo != null) {
                return localTodo
            }

            // If not in local database, fetch from network
            val remoteTodo = apiService.getTodo(id)
            // Update local database
            todoDao.insert(remoteTodo)
            return remoteTodo
        } catch (e: Exception) {
            // If network fails, try local database again
            val localTodo = todoDao.getTodoById(id)
            if (localTodo != null) {
                return localTodo
            }
            throw e
        }
    }
}